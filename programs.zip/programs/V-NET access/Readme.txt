In V-Access after the PLC is added to the V-net
Make sure plc ID on the Excet sheet is same as the PLC ID provided at V-Access Communication Tab